from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'VBFZto2Q_TuneCP5_13p6TeV_madgraph-pythia8_Run3_lgeneros'
config.General.workArea = 'resultsAna_/'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = '/afs/cern.ch/user/l/lgeneros/Hcc-studies-lxp8/CMSSW_13_0_13/src/Hcc/HccAna/python/templateMC_QCDZqq_Summer23_JECdB.py'
config.JobType.inputFiles = ['/afs/cern.ch/user/l/lgeneros/Hcc-studies-lxp8/CMSSW_13_0_13/src/Hcc/HccAna/python/Summer23Prompt23_V1_MC.db', '/afs/cern.ch/user/l/lgeneros/Hcc-studies-lxp8/CMSSW_13_0_13/src/Hcc/HccAna/python/Summer23Prompt23_RunCv1234_JRV1_MC.db', '/afs/cern.ch/user/l/lgeneros/Hcc-studies-lxp8/CMSSW_13_0_13/src/Hcc/HccAna/python/Summer23Prompt23_V1_MC_UncertaintySources_AK4PFPuppi.txt']
config.JobType.numCores = 2
config.section_('Data')
config.Data.outputDatasetTag = '130X_mcRun3_2023_realistic_v14_tuple'
config.Data.inputDBS = 'phys03'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 3
config.Data.inputDataset = '/VBFZto2Q_TuneCP5_13p6TeV_madgraph-pythia8_Run3/lgeneros-130X_mcRun3_2023_realistic_v15_MINIAODSIM-7001f3c84dd6738fff9549020f956887/USER'
config.Data.allowNonValidInputDataset = True
config.section_('Site')
config.Site.storageSite = 'T2_IT_Bari'
config.Site.ignoreGlobalBlacklist = True
config.section_('User')
config.section_('Debug')
